#!/bin/sh

sass --watch assets/style.scss:assets/style.css --style compressed

exit 0
