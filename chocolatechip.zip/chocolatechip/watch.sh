#!/bin/sh

sass --watch _assets/style.scss:_assets/style.css --style compressed

exit 0
