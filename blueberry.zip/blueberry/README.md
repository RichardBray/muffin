HTML5 Muffin chocchip steps
============================

Run bundle install

	bundle install

Run jekyll

	jekyll